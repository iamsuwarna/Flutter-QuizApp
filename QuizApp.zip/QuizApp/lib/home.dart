import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mentor_quiz_app_tut/answer.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Icon> Track = [];
  int number_question = 0;
  int score = 0;
  bool selectanswer = false;
  bool quiz_ending = false;
  bool rightanswer = false;

  void _questionAnswered(bool answerScore) {
    setState(() {
      // answer was selected
      selectanswer = true;
      // check if answer was correct
      if (answerScore) {
        score++;
        rightanswer = true;
      }
      // adding to the score tracker on top
      Track.add(
        answerScore
            ? Icon(
          Icons.check_circle,
          color: Colors.green,
        )
            : Icon(
          Icons.clear,
          color: Colors.red,
        ),
      );
      //when the quiz ends
      if (number_question + 1 == _questions.length) {
        quiz_ending = true;
      }
    });
  }

  void _nextQuestion() {
    setState(() {
      number_question++;
      selectanswer = false;
      rightanswer = false;
    });
    // what happens at the end of the quiz
    if (number_question >= _questions.length) {
      _resetQuiz();
    }
  }

  void _resetQuiz() {
    setState(() {
      number_question = 0;
      score = 0;
      Track = [];
      quiz_ending = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.deepPurpleAccent.shade200,
        title: RichText(
          text: TextSpan(
              children: [
                TextSpan(text: 'Quiz', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.black45)),
                TextSpan(text: 'App', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white54))
              ]
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          children: [
            Row(
              children: [
                if (Track.length == 0)
                  SizedBox(
                    height: 25.0,
                  ),
                if (Track.length > 0) ...Track
              ],
            ),
            Container(
              width: double.infinity,
              height: 130.0,
              margin: EdgeInsets.only(bottom: 5.0, left: 30.0, right: 30.0),
              padding: EdgeInsets.symmetric(horizontal: 50.0, vertical: 20.0),
              decoration: BoxDecoration(
                color: Colors.deepPurpleAccent.shade100,
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Center(
                child: Text(
                  _questions[number_question]['question'],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            ...(_questions[number_question]['answers']
            as List<Map<String, Object>>)
                .map(
                  (answer) => Answer(
                answerText: answer['answerText'],
                answerColor: selectanswer
                    ? answer['score']
                    ? Colors.green
                    : Colors.red
                    : null,
                answerTap: () {
                  // if answer was already selected then nothing happens onTap
                  if (selectanswer) {
                    return;
                  }
                  //answer is being selected
                  _questionAnswered(answer['score']);
                },
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor: getColor(Colors.deepPurpleAccent.shade200, Colors.red),
              ),
              // style: ElevatedButton.styleFrom(
              //   minimumSize: Size(double.infinity, 40.0),
              //
              //
              //
              // ),

              onPressed: () {
                if (!selectanswer) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(
                        'Please select an answer before going to the next question'),
                  ));
                  return;
                }
                _nextQuestion();
              },
              child: Text(

                  quiz_ending ? 'Restart Quiz' : 'Next Question'
              ),
            ),
            Container(
              padding: EdgeInsets.all(20.0),
              child: Text(
                '${score.toString()}/${_questions.length}',
                style: TextStyle(fontSize: 40.0, fontWeight: FontWeight.bold),
              ),
            ),
            if (selectanswer && !quiz_ending)
              Container(
                height:16,
                width: double.infinity,
                child: Center(
                  child: Text(
                    rightanswer
                        ? 'Right Answer!'
                        : 'Wrong Answer!',
                    style: TextStyle(
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold,
                      color: rightanswer ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              ),
            if (quiz_ending)
              Container(
                margin: EdgeInsets.only(bottom: 5),
                height: 30,
                width: double.infinity,
                color: Colors.black,
                child: Center(
                  child: Text(
                    score > 5
                        ? 'Congratulations! Your final score is: $score'
                        : 'Your final score is: $score. Try your luck next time!!',
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                      color: score > 5 ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  MaterialStateProperty<Color>getColor(Color color, Color pressed_color) {

    final getColor = (Set<MaterialState> states){
      if(states.contains(MaterialState.pressed)) {
        return pressed_color;
      }
      else{
        return color;
      }
    };
    return MaterialStateProperty.resolveWith(getColor);
  }
}

final _questions = const [
  {
    'question': 'What does LGBTQ stand for?',
    'answers': [
      {'answerText': 'Lesbian, gay, bisexual, transgender, and questioning (or queer)', 'score': true},
      {'answerText': 'Lady, Guy, Bisexual, Transgender and Queen', 'score': false},
      {'answerText': 'Lesbo, Girl, Bully, transgender, and queer', 'score': false},
    ],
  },
  {
    'question':
    'What was the name of Britney Spears first single?'
    ,
    'answers': [
      {'answerText': 'Baby One More Time', 'score': true},
      {'answerText': 'Love me more', 'score': false},
      {'answerText': 'Let it go', 'score': false},
    ],
  },
  {
    'question': 'Who composed the music for Sonic the Hedgehog 3?',
    'answers': [
      {'answerText': 'Britney Spears', 'score': false},
      {'answerText': 'Timbaland', 'score': false},
      {'answerText': 'Michael Jackson', 'score': true},
    ],
  },
  {
    'question': 'What does a Geiger Counter measure?',
    'answers': [
      {'answerText': 'Weight', 'score': false},
      {'answerText': 'Radiation', 'score': true},
      {'answerText': 'Temperature', 'score': false},
    ],
  },
  {
    'question':
    'What is the smallest country in the world?',
    'answers': [
      {'answerText': 'Vatican City', 'score': true},
      {'answerText': 'Nepal', 'score': false},
      {'answerText': 'Peru', 'score': false},
    ],
  },
  {
    'question': 'Which country\'s rugby team is known as The Springboks?',
    'answers': [
      {'answerText': 'Ecuador', 'score': false},
      {'answerText': 'South Africa', 'score': true},
      {'answerText': 'Portugal', 'score': false},
    ],
  },
  {
    'question': 'Which is the highest grossing Harry Potter film?',
    'answers': [
      {'answerText': 'Harry potter part1', 'score': false},
      {'answerText': 'Harry potter part2 ', 'score': false},
      {'answerText': 'Harry Potter and the Deathly Hallows - Part 2', 'score': true},
    ],
  },
  {
    'question': 'Who is the highest spiritual leader of Tibet?',
    'answers': [
      {'answerText': 'Gautam Buddha', 'score': false},
      {'answerText': 'Zengonj Yela', 'score': false},
      {'answerText': 'The Dalai Lama', 'score': true},
    ],
  },
  {
    'question': 'Who came second in the FIFA Women\'s World Cup in 2019?',
    'answers': [
      {'answerText': 'Belgium', 'score': false},
      {'answerText': 'The Netherlands', 'score': true},
      {'answerText': 'Switzerland', 'score': true},
    ],
  },
];
